document.getElementById("btnryde").addEventListener("click",check);

function click()
{
	document.getElementById("salaryResults").innerHTML ="btn click!";
	//take the values
	var from = document.getElementById("from").value;
	var to = document.getElementById("to").value;

	//take value of radio btn
	var ridepool = document.getElementById("pool").value;
    var ridedirect = document.getElementById("direct").value;
	var ridetype;
	var distance = 0;
	
	//validate values and assign distance else show alert box
	if(from=="" && to =="")
	{
		alert("Please enter a valid value!");
  		console.log("Please enter a valid value!");
	}
	else if(from=="275 Yorkland Blvd" && to =="CN Tower")
	{
		distance = 22.9;
		console.log("From : " + from);
    		console.log("To : " + to);
	
		if(document.getElementById("pool").checked)
			{
   					ridetype="pool";
			}
		else if( document.getElementById("direct").checked)
			{
   				ridetype="direct";		
			}			
	}
	else if(from=="Fairview Mall" && to =="Tim Hortons")
	{
		distance = 1.2;
		 console.log("From : " + from);
        console.log("To : " + to);
	if(document.getElementById("pool").checked)
			{
   					ridetype="pool";
			}
		else if( document.getElementById("direct").checked)
			{
   				ridetype="direct";		
			}				
	}
	else
	{
		
			alert("Please enter a valid value!");
  		console.log("Please enter a valid value!");
	}

	//calculate the price
	var totalprice;
	var basefare = 2.50;
	var distancecharge = 0.81/distance;
	var servicefees = 1.75;
	
	totalprice =  basefare + distancecharge + servicefees;
	
  //minimum fare
	var minfare = 5.50;
	 if(totalprice<minfare)
	 {
	 	totalprice=5.50;
	 }
	
	 //adding ride type
	 if(ridetype="direct")
	 {
	 	basefare= 2.50*0.10;
		 totalprice = basefare + distancecharge + servicefees;
	 }
	 
	 //confirmation
	 document.getElementById("Result").innerHTML =   "<h2>Ryde pool confirmed!</h2> " + "<br>" 
  + "From: " + from + "<br>"
  + "To: " + to + "<br>"
  + "Booking Fee: " + basefare + "<br>"  
  + "Distance Charge: " + distancecharge + "<br>" 
  + "Service Fee: " + servicefees + "<br>" 
  + "Total: " + totalprice + "<br>" 
	 ;
	 
	 
}
